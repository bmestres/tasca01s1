package tascaS101.nivell02.exercici01;

public interface Clock {
    // Declare ringing alarm action
    void ringAlarm();
}